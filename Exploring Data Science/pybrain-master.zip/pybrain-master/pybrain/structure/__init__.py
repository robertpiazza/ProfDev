from pybrain.structure.connections.__init__ import *
from pybrain.structure.modules.__init__ import *
from pybrain.structure.networks.__init__ import *
from pybrain.structure.modulemesh import ModuleMesh